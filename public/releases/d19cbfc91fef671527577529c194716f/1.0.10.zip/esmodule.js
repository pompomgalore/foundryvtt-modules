// scripts/foundry/module/constants.ts
var MODULE_ID = "dngnr-gos";
var SOURCE_TITLE = "Ghosts of Saltmarsh";

// scripts/foundry/module/compendium/getNpcCompendium.ts
async function getNpcCompendium() {
  const packId = `${MODULE_ID}-npcs`;
  if (game.packs) {
    const existing = game.packs.get(`world.${packId}`);
    if (existing) {
      return existing;
    }
  }
  return await foundry.documents.collections.CompendiumCollection.createCompendium({
    type: "Actor",
    name: packId,
    label: `${SOURCE_TITLE} NPCs`,
    banner: `modules/${MODULE_ID}/assets/banner.webp`,
    locked: true
  });
}

// scripts/foundry/module/compendium/getNpcIdMap.ts
async function getNpcIdMap(npcCompendium) {
  const index = await npcCompendium.getIndex({ fields: ["name"] });
  const map = /* @__PURE__ */ new Map();
  for (const { _id, name } of index) {
    if (!name) {
      continue;
    }
    map.set(name, _id);
  }
  return map;
}

// scripts/foundry/module/utils/getJson.ts
async function getJson(filePath) {
  return fetch(`modules/${MODULE_ID}/${filePath}`).then((r) => r.json());
}

// scripts/foundry/module/utils/log.ts
function log(message, level = "log") {
  console[level](
    `%c${MODULE_ID}%c | ${message}`,
    `color: #6e0000; font-variant: small-caps`,
    "color: revert"
  );
}

// scripts/foundry/module/utils/prepareProgress.ts
function prepareProgress(message, length) {
  if (!ui.notifications || length <= 0) {
    throw new Error("UI notifications not found or invalid length.");
  }
  const notification = ui.notifications.info(message, { progress: true, console: false });
  return (index = length) => {
    notification.update({ pct: Math.min((index + 1) / length, 1) });
    if (index === length) {
      notification.remove();
    }
  };
}

// scripts/foundry/module/utils/slugify.ts
function slugify(input) {
  return String(input ?? "").toLowerCase().trim().replace(/[’']/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

// scripts/foundry/module/statblocks/applyStatblocks.ts
function lockCompendium(compendium, locked) {
  return compendium.configure({ locked });
}
async function applyStatblocks(compendium, npcIdMap, npcsData, selection) {
  const updateMessage = `Updating ${SOURCE_TITLE} NPCs compendium...`;
  const updateProgress = prepareProgress(updateMessage, npcsData.length);
  log(updateMessage);
  await lockCompendium(compendium, false);
  try {
    const statblockMap = await buildStatblockMap(selection);
    let index = 0;
    const batch = npcsData.values().map(async (npcData) => {
      const statblockData = await getNpcStatblockData(npcData, statblockMap);
      const mergedData = statblockData ? foundry.utils.mergeObject(statblockData, npcData, {
        inplace: false
      }) : npcData;
      const actorData = foundry.utils.mergeObject(
        mergedData,
        {
          type: "npc",
          system: {
            source: { book: SOURCE_TITLE }
          },
          prototypeToken: {
            actorLink: true,
            displayBars: CONST.TOKEN_DISPLAY_MODES.OWNER_HOVER,
            lockRotation: true,
            disposition: CONST.TOKEN_DISPOSITIONS.NEUTRAL,
            displayName: CONST.TOKEN_DISPLAY_MODES.OWNER_HOVER,
            ring: null,
            randomImg: false
          },
          flags: {
            [MODULE_ID]: {
              hasStatblock: !!statblockData
            }
          },
          folder: null,
          sort: 0
        },
        { inplace: false }
      );
      const npcId = npcIdMap.get(actorData.name);
      if (npcId) {
        await Actor.implementation.updateDocuments(
          [{ _id: npcId, ...actorData }],
          { pack: compendium.collection }
        );
      } else {
        const [created] = await Actor.implementation.createDocuments(
          [actorData],
          { pack: compendium.collection }
        );
        npcIdMap.set(created.name, created.id);
      }
      updateProgress(index);
      index += 1;
    });
    await Promise.all(batch).then(() => {
      log(`${SOURCE_TITLE} NPCs compendium successfully updated.`);
      updateProgress();
    });
  } finally {
    await lockCompendium(compendium, true);
  }
}

// scripts/foundry/module/statblocks/buildStatblockMap.ts
async function buildStatblockMap(compendia) {
  const index = /* @__PURE__ */ new Map();
  for (const pack of compendia) {
    const entries = await pack.getIndex({ fields: ["name"] });
    for (const { _id, name } of entries) {
      if (!name) {
        continue;
      }
      const key = slugify(name);
      if (key && !index.has(key)) {
        index.set(key, async () => await pack.getDocument(_id) ?? null);
      }
    }
  }
  return index;
}

// scripts/foundry/module/statblocks/findNpcStatblock.ts
async function findNpcStatblock(npcData, statblocks) {
  const monsterName = npcData.flags?.[MODULE_ID]?.dndMonsterName;
  if (monsterName) {
    const monsterKey = slugify(monsterName);
    const monsterRef = statblocks.get(monsterKey);
    if (monsterRef) {
      return monsterRef();
    }
  }
  const name = npcData.name;
  const nameKey = slugify(name);
  const nameRef = statblocks.get(nameKey);
  if (nameRef) {
    return nameRef();
  }
  const race = npcData.system?.details?.race;
  if (race) {
    const raceKey = slugify(race);
    const raceRef = statblocks.get(raceKey);
    if (raceRef) {
      return raceRef();
    }
  }
  return null;
}

// scripts/foundry/module/statblocks/getActorPacks.ts
function getActorPacks() {
  if (!game.packs) {
    throw new Error("Game packs not found.");
  }
  return Array.from(game.packs).filter((pack) => {
    if (pack.metadata.id.startsWith(`world.dngnr-`)) {
      return false;
    }
    const documentName = pack?.documentName ?? pack?.metadata?.type;
    return documentName === "Actor";
  }).sort((a, b) => a.metadata.id.localeCompare(b.metadata.id));
}

// scripts/foundry/module/statblocks/getNpcStatblockData.ts
async function getNpcStatblockData(npcData, statblocks) {
  const actor = await findNpcStatblock(npcData, statblocks);
  if (!actor) {
    log(`No statblock found for NPC "${npcData.name}".`);
    return null;
  }
  const data = actor.toObject();
  delete data._id;
  delete data._stats;
  return data;
}

// scripts/foundry/module/settings/index.ts
Hooks.once("init", () => {
  if (!game.settings) {
    throw new Error("Game settings not found.");
  }
  game.settings.register(MODULE_ID, "statblockCompendia", {
    name: `${SOURCE_TITLE} Statblocks`,
    hint: `Compendia to scan for statblocks compatible with the ${SOURCE_TITLE} characters.`,
    scope: "world",
    config: false,
    type: Object,
    default: {}
  });
});
function getSettings(key, defaultValue) {
  if (!game.settings) {
    throw new Error("Game settings not found.");
  }
  const value = game.settings.get(MODULE_ID, key);
  return value ?? defaultValue;
}
async function setSettings(key, value) {
  if (!game.settings) {
    throw new Error("Game settings not found.");
  }
  await game.settings.set(MODULE_ID, key, value);
}

// scripts/foundry/module/settings/statblockCompendia.ts
function getStatblockCompendia() {
  return getSettings("statblockCompendia", null);
}
async function setStatblockCompendia(value) {
  return setSettings("statblockCompendia", value);
}

// scripts/foundry/module/ui/selectStatblockCompendia.ts
function getDefaultSelection(actorPacks) {
  if (!game.system) {
    throw new Error("Game system not found.");
  }
  return actorPacks.map((pack) => pack.metadata.id).filter((id) => id.includes(game.system.id));
}
function getInitialSelection(actorPacks) {
  const statblockCompendia = getStatblockCompendia();
  if (!statblockCompendia) {
    return getDefaultSelection(actorPacks);
  }
  const selection = Object.entries(statblockCompendia).reduce(
    (acc, [packName, enabled]) => {
      if (enabled && (!actorPacks || actorPacks.some((pack) => pack.metadata.id === packName))) {
        acc.push(packName);
      }
      return acc;
    },
    []
  );
  return selection;
}
async function setSelection(selection) {
  const value = {};
  for (const pack of selection) {
    value[pack.metadata.id] = true;
  }
  await setStatblockCompendia(value);
}
var getFormHtml = (packs, initialSelection) => {
  return `<form><p>Select the compendia to scan for statblocks compatible with the <strong>${foundry.utils.escapeHTML(SOURCE_TITLE)}</strong> characters.</p><p>${packs.map((pack) => {
    const checked = initialSelection.includes(pack.metadata.id);
    return `<label class="checkbox"><input type="checkbox" name="actor-pack" value="${foundry.utils.escapeHTML(pack.metadata.id)}" ${checked ? "checked" : ""} /><span>${foundry.utils.escapeHTML(pack.title)} <em style="color: var(--color-form-hint)">${foundry.utils.escapeHTML(pack.metadata.id)}</em></span></label>`;
  }).join("")}</p></form>`;
};
async function selectStatblockCompendia() {
  const actorPacks = getActorPacks();
  const packs = actorPacks;
  if (!packs.length) {
    return null;
  }
  const initialSelection = getInitialSelection(actorPacks);
  const result = await foundry.applications.api.DialogV2.wait({
    window: { title: `${SOURCE_TITLE} NPCs` },
    content: getFormHtml(packs, initialSelection),
    buttons: [
      {
        action: "cancel",
        icon: "fa-solid fa-times",
        label: "Cancel",
        callback: () => null
      },
      {
        action: "save",
        icon: "fa-solid fa-refresh",
        label: "Apply Statblocks",
        default: true,
        callback: (_event, button) => {
          if (!button.form) {
            return null;
          }
          const checkedPacks = button.form.querySelectorAll(
            'input[name="actor-pack"]:checked'
          );
          return Array.from(checkedPacks).map((inputElement) => actorPacks.find((p) => p.metadata.id === inputElement.value)).filter((pack) => Boolean(pack));
        }
      }
    ],
    rejectClose: false
  });
  if (!result || typeof result === "string") {
    return null;
  }
  const compendia = result;
  await setSelection(compendia);
  return compendia;
}

// scripts/foundry/module/ui/renderCompendiumActions.ts
function renderCompendiumActions(app, html, compendium) {
  const $header = $(html).find("header.compendium-header");
  $header.find("button.collapse-all").remove();
  const $actions = $header.find(".header-actions");
  if ($actions.length >= 0 && $actions.find(".apply-statblocks").length === 0) {
    const $btn = $(
      `<button type="button" class="apply-statblocks"><i class="fa-solid fa-refresh"></i><span>Apply Statblocks</span></button>`
    ).on("click", async (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      $btn.prop("disabled", true);
      try {
        const npcIdMap = await getNpcIdMap(compendium);
        const npcsData = await getJson("assets/data.json");
        const selection = await selectStatblockCompendia();
        if (selection) {
          app.close({ animate: false });
          await applyStatblocks(compendium, npcIdMap, npcsData, selection);
        }
      } catch (err) {
        console.error(err);
      } finally {
        $btn.prop("disabled", false);
      }
    });
    $actions.empty();
    $actions.append($btn);
  }
}

// scripts/foundry/module/ui/renderCompendiumStatblockIndicators.ts
function renderCompendiumStatblockIndicators(html, compendium) {
  for (const entry of $(html).find("li.entry.actor")) {
    const $entry = $(entry);
    if ($entry.find("i.statblock-indicator").length > 0) {
      continue;
    }
    const entryId = $entry.data("entryId");
    compendium.getDocument(entryId).then((actor) => {
      if (!actor || !actor.flags || !(MODULE_ID in actor.flags) || // eslint-disable-next-line @typescript-eslint/no-explicit-any
      actor.flags[MODULE_ID].hasStatblock) {
        return;
      }
      const $entryName = $entry.find(".entry-name");
      $entryName.css({
        paddingRight: "2em"
      });
      const $indicator = $("<i>").addClass("fa-solid fa-circle-exclamation").addClass("statblock-indicator").attr("aria-hidden", "true").css({
        position: "absolute",
        right: "0.5em",
        top: "50%",
        transform: "translateY(-50%)"
      });
      const monsterName = actor.flags[MODULE_ID].dndMonsterName;
      if (monsterName) {
        $entryName.append(
          $indicator.attr(
            "data-tooltip-text",
            `Statblock for ${foundry.utils.escapeHTML(monsterName)} not found.`
          ).css({
            color: "var(--color-text-accent)"
          })
        );
      } else {
        $entryName.append(
          $indicator.attr("data-tooltip-text", `No statblock defined.`).css({
            color: "var(--color-form-hint)"
          })
        );
      }
    });
  }
}

// scripts/foundry/module/ui/index.ts
Hooks.on(
  "renderCompendium",
  async (app, html) => {
    const compendium = app.collection;
    if (!compendium || compendium.documentName !== "Actor" || compendium.metadata?.name !== `${MODULE_ID}-npcs`) {
      return;
    }
    renderCompendiumActions(app, html, compendium);
    renderCompendiumStatblockIndicators(html, compendium);
  }
);

// scripts/foundry/module/index.ts
Hooks.once("ready", async () => {
  const compendium = await getNpcCompendium();
  const npcIdMap = await getNpcIdMap(compendium);
  const npcsData = await getJson("assets/data.json");
  if (npcIdMap.size >= npcsData.length) {
    log(`${SOURCE_TITLE} NPCs compendium is up to date.`);
    return;
  }
  const selection = await selectStatblockCompendia();
  if (!selection) {
    return log("NPC compendium update cancelled.");
  }
  await applyStatblocks(compendium, npcIdMap, npcsData, selection);
});
